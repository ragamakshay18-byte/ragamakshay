from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from groq import Groq
import os
from dotenv import load_dotenv
import re
from typing import List, Optional

# ── Load environment variables from .env file ──────────────────────────────
load_dotenv()

# ── Initialize FastAPI app ──────────────────────────────────────────────────
app = FastAPI(title="AI Code Review & Rewrite Agent")

# ── Allow frontend to talk to backend (CORS) ───────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Initialize Groq client ──────────────────────────────────────────────────
groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# ── Model settings ──────────────────────────────────────────────────────────
MODEL_NAME    = "llama-3.3-70b-versatile"
TEMPERATURE   = 0.3
MAX_TOKENS    = 2000
TOP_P         = 0.9

# ── Request / Response schemas ──────────────────────────────────────────────
class CodeReviewRequest(BaseModel):
    code: str
    language: str = "python"
    focus_areas: List[str] = ["bugs", "security", "performance", "best_practices"]

class CodeRewriteRequest(BaseModel):
    code: str
    language: str = "python"
    review_feedback: Optional[str] = ""

class CodeReviewResponse(BaseModel):
    review_text: str
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int

class CodeRewriteResponse(BaseModel):
    rewritten_code: str
    improvements: List[str]
    explanation: str


# ── Helper: parse severity counts from review text ─────────────────────────
def parse_review_response(review_text: str) -> dict:
    """Parse the LLM response to extract structured severity counts."""

    critical_section = re.search(r'###\s*🔴\s*Critical Issues.*?(?=###|\Z)', review_text, re.DOTALL)
    high_section     = re.search(r'###\s*🟠\s*High Priority.*?(?=###|\Z)',    review_text, re.DOTALL)
    medium_section   = re.search(r'###\s*🟡\s*Medium Priority.*?(?=###|\Z)', review_text, re.DOTALL)
    low_section      = re.search(r'###\s*🟢\s*Low Priority.*?(?=###|\Z)',    review_text, re.DOTALL)

    def count_bullets(section_match):
        if not section_match:
            return 0
        text = section_match.group(0)
        return len(re.findall(r'^\s*[-*•]', text, re.MULTILINE))

    return {
        "critical_count": max(count_bullets(critical_section), 0),
        "high_count":     max(count_bullets(high_section),     0),
        "medium_count":   max(count_bullets(medium_section),   0),
        "low_count":      max(count_bullets(low_section),      0),
    }


# ── Helper: parse improvements list from rewrite response ──────────────────
def parse_rewrite_response(rewrite_text: str) -> dict:
    """Extract rewritten code block, improvements, and explanation."""

    # Extract code block
    code_match = re.search(r'```(?:\w+)?\n(.*?)```', rewrite_text, re.DOTALL)
    rewritten_code = code_match.group(1).strip() if code_match else rewrite_text

    # Extract improvements
    improvements = re.findall(r'\*\*(.*?)\*\*[:\s]+(.*?)(?=\n|$)', rewrite_text)
    improvement_list = [f"{title}: {desc}" for title, desc in improvements[:6]]

    # Extract explanation
    explanation_match = re.search(r'(?:Explanation|Summary)[:\s]+(.*?)(?=\n\n|\Z)', rewrite_text, re.DOTALL | re.IGNORECASE)
    explanation = explanation_match.group(1).strip() if explanation_match else "Code has been optimized and rewritten following best practices."

    return {
        "rewritten_code": rewritten_code,
        "improvements":   improvement_list if improvement_list else ["Code structure improved", "Best practices applied", "Security enhancements made"],
        "explanation":    explanation,
    }


# ── Routes ──────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_login():
    """Serve the login page."""
    try:
        with open("../frontend/login.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="<h1>❌ login.html not found</h1>")


@app.get("/app", response_class=HTMLResponse)
async def serve_tool():
    """Serve the main tool page after login."""
    try:
        with open("../frontend/index.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="<h1>❌ index.html not found</h1>")


@app.post("/api/review", response_model=CodeReviewResponse)
async def review_code(request: CodeReviewRequest):
    """Review code and return structured feedback using Groq API."""

    if not request.code.strip():
        raise HTTPException(status_code=400, detail="Code cannot be empty")

    focus_str = ", ".join(request.focus_areas)

    prompt = f"""You are an expert code reviewer with 15+ years of experience. Analyze this {request.language} code focusing on: {focus_str}.

CODE TO REVIEW:
```{request.language}
{request.code}
```

Respond EXACTLY in this format:

## 📊 Overall Assessment
[2-3 sentence summary of the code quality]

### 🔴 Critical Issues (Must Fix)
- [Issue description with line reference if possible]

### 🟠 High Priority
- [Issue description]

### 🟡 Medium Priority
- [Issue description]

### 🟢 Low Priority
- [Suggestion]

## 💡 Quick Suggestions
[3-5 specific actionable improvements as a numbered list]
"""

    try:
        response = groq_client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
            top_p=TOP_P,
        )
        review_text = response.choices[0].message.content
        counts = parse_review_response(review_text)

        return CodeReviewResponse(
            review_text=review_text,
            **counts
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Groq API error: {str(e)}")


@app.post("/api/rewrite", response_model=CodeRewriteResponse)
async def rewrite_code(request: CodeRewriteRequest):
    """Rewrite and optimize code using Groq API."""

    if not request.code.strip():
        raise HTTPException(status_code=400, detail="Code cannot be empty")

    prompt = f"""You are an expert software engineer. Rewrite and optimize this {request.language} code to be production-ready.

ORIGINAL CODE:
```{request.language}
{request.code}
```

{f"REVIEW FEEDBACK TO ADDRESS: {request.review_feedback}" if request.review_feedback else ""}

Requirements for rewrite:
1. Fix ALL bugs and security vulnerabilities
2. Optimize for performance
3. Follow {request.language} best practices and conventions
4. Add proper error handling
5. Add helpful docstrings/comments
6. Use clear, descriptive variable names

Respond in this EXACT format:

## ✨ Rewritten Code
```{request.language}
[YOUR COMPLETE REWRITTEN CODE HERE]
```

## 🚀 Key Improvements
**Type Hints**: Description of improvement
**Error Handling**: Description of improvement
**Security**: Description of improvement
**Performance**: Description of improvement

## Explanation
[2-3 sentences summarizing what was changed and why]
"""

    try:
        response = groq_client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
            top_p=TOP_P,
        )
        rewrite_text = response.choices[0].message.content
        parsed = parse_rewrite_response(rewrite_text)

        return CodeRewriteResponse(**parsed)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Groq API error: {str(e)}")


@app.get("/api/health")
async def health_check():
    """Check if the API and Groq connection are working."""
    try:
        groq_client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=5,
        )
        return {"status": "healthy", "groq": "connected", "model": MODEL_NAME}
    except Exception as e:
        return {"status": "degraded", "groq": "error", "error": str(e)}


# ── Run server ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    print("=" * 60)
    print("  🤖 AI Code Review & Rewrite Agent")
    print("=" * 60)
    print("  ✅ Login Page : http://localhost:8000")
    print("  ✅ Tool Page  : http://localhost:8000/app")
    print("  ✅ API Docs   : http://localhost:8000/docs")
    print("=" * 60)
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
